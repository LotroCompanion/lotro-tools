_ITEMSDB =
{
[1879049652]={[1]="Lesser Celebrant Salve";[2]="";[3]=5;[4]=4;[5]=3;[6]=false;[7]=false;[8]=0x410D9916;[9]=0x41000002;};
};
