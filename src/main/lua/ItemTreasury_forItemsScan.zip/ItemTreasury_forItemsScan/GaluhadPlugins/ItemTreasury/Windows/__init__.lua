
import (PLUGINDIR..".Windows.MainWin");

function DrawWindows()
	DrawMainWin();
end
